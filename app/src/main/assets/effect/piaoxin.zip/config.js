{
    "version": "1"
    ,"audio":[{
              "start":14,
              "end":1,
              "filename":"music1.mp3",
              "repeat":true
              },{
              "start": 4,
              "end": 0,
              "duration": 3.0,
              "filename":"music2.mp3",
              "repeat":true
              }]
    ,"2d": [{
            "start": 14
            ,"end": 1
            ,"duration": 0
            ,"vertex": "common.vsh"
            ,"fragment": "common.fsh"
            ,"faceIndexs":[0]
            ,"renderOrders":[0]
            ,"texCoorName":"kuang"
            ,"width":0.9912
            ,"height":1.9824
            ,"posx":0
            ,"posy":0
            ,"rollType":0
            ,"rollOffset":0
            },{
            "start": 14
            ,"end": 1
            ,"duration": 0
            ,"vertex": "common.vsh"
            ,"fragment": "common.fsh"
            ,"faceIndexs":[0]
            ,"renderOrders":[0]
            ,"texCoorName":"heart"
            ,"width":1.064
            ,"height":2.128
            ,"posx":0
            ,"posy":0
            ,"rollType":0
            ,"rollOffset":0
            },{
            "start": 4
            ,"end": 0
            ,"duration": 5
            ,"vertex": "common.vsh"
            ,"fragment": "common.fsh"
            ,"faceIndexs":[0]
            ,"renderOrders":[0]
            ,"texCoorName":"love"
            ,"width":1.008
            ,"height":2.016
            ,"posx":0
            ,"posy":0
            ,"rollType":0
            ,"rollOffset":0
            ,"affector":[
                         {
                         "affectorType":2,
                         "affector_needReverse":false,
                         "affector_startTime":0.0,
                         "affector_endTime":1.0,
                         "affector_totalTime":5.0,
                         "affector_startAlpha":0,
                         "affector_endAlpha":0
                         },{
                         "affectorType":2,
                         "affector_needReverse":false,
                         "affector_startTime":1.0,
                         "affector_endTime":5.0,
                         "affector_totalTime":5.0,
                         "affector_startAlpha":1.0,
                         "affector_endAlpha":1.0
                         },{
                         "affectorType":4,
                         "affector_totalTime":5.0,
                         "affector_frameTimes":[1.0,5.0],
                         "affector_frameNames":"love"
                         }
            ]
            }
           ]
}
