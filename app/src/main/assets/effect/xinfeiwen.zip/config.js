{
    "version": "1"
    ,"face": {
        "start": 14
        ,"vertex": "face1.vsh"
        ,"fragment": "face1.fsh"
        ,"count":4
        ,"extra":[1.0,0.5,1.0, 0.1, 2.0,0.0036,0.105, 1.193,1.28,0.0232, 0.413,0.29]
        ,"shouxiaba1":"shouxiaba1"
    }
    ,"2d": [{
            "start": 14
            ,"end": 1
            ,"duration": 0
            ,"vertex": "common.vsh"
            ,"fragment": "common.fsh"
            ,"faceIndexs":[0]
            ,"renderOrders":[0]
            ,"texCoorName":"left_hand"
            ,"width":0.675
            ,"height":1.35
            ,"posx":-0.74
            ,"posy":0.65
            ,"rollType":1
            ,"rollOffset":0.4
            ,"bindFaceIndex":"faceBottom"
            },{
            "start": 14
            ,"end": 1
            ,"duration": 0
            ,"vertex": "common.vsh"
            ,"fragment": "common.fsh"
            ,"faceIndexs":[0]
            ,"renderOrders":[1]
            ,"texCoorName":"right_hand"
            ,"width":0.675
            ,"height":1.35
            ,"posx":0.74
            ,"posy":0.65
            ,"rollType":1
            ,"rollOffset":-0.4
            ,"bindFaceIndex":"faceBottom"
            },{
            "start": 14
            ,"end": 1
            ,"duration": 0
            ,"vertex": "common.vsh"
            ,"fragment": "common.fsh"
            ,"faceIndexs":[0]
            ,"renderOrders":[2]
            ,"texCoorName":"xin"
            ,"width":0.1
            ,"height":0.1
            ,"posx":-2.8
            ,"posy":2.0
            ,"rollType":1
            ,"rollOffset":0
            ,"bindFaceIndex":"bridgeOfNose1"
            },{
            "start": 14
            ,"end": 1
            ,"duration": 0
            ,"vertex": "common.vsh"
            ,"fragment": "common.fsh"
            ,"faceIndexs":[0]
            ,"renderOrders":[3]
            ,"texCoorName":"feiwenxin"
            ,"width":1.2
            ,"height":0.6
            ,"posx":0.3
            ,"posy":-0.3
            ,"rollType":1
            ,"rollOffset":0
            ,"bindFaceIndex":"faceBottom"
            }
           ]
}
